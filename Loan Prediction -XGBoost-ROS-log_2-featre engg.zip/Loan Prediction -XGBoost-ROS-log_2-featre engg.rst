.. code:: ipython3

    #import all the necessary libraries
    import numpy as np #provides high-performance multidimensional array with manipulation tool
    import pandas as pd #Python-based data analysis toolkit
    import matplotlib.pyplot as plt #plotting library for the Python and its numerical mathematics extension NumPy.
    import seaborn as sns #Python data visualization library based on matplotlib
    import math #To use mathematical functions
    import matplotlib
    import sklearn #most useful library for machine learning and statistical modelling
    import scipy #uses NumPy for more mathematical functions
    import warnings #provided to warn the developer of situations that aren’t necessarily exceptions
    warnings.filterwarnings('ignore')

.. code:: ipython3

    #import the datasets
    df1 = pd.read_csv("train_ctrUa4K.csv")
    df2 = pd.read_csv("test_lAUu6dG.csv") 

.. code:: ipython3

    train_original = df1.copy()
    test_original = df2.copy()

.. code:: ipython3

    df1.columns




.. parsed-literal::

    Index(['Loan_ID', 'Gender', 'Married', 'Dependents', 'Education',
           'Self_Employed', 'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
           'Loan_Amount_Term', 'Credit_History', 'Property_Area', 'Loan_Status'],
          dtype='object')



.. code:: ipython3

    df2.columns




.. parsed-literal::

    Index(['Loan_ID', 'Gender', 'Married', 'Dependents', 'Education',
           'Self_Employed', 'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
           'Loan_Amount_Term', 'Credit_History', 'Property_Area'],
          dtype='object')



.. code:: ipython3

    #check for the detailed datatypes of the training dataset 
    df1.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 614 entries, 0 to 613
    Data columns (total 13 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Loan_ID            614 non-null    object 
     1   Gender             601 non-null    object 
     2   Married            611 non-null    object 
     3   Dependents         599 non-null    object 
     4   Education          614 non-null    object 
     5   Self_Employed      582 non-null    object 
     6   ApplicantIncome    614 non-null    int64  
     7   CoapplicantIncome  614 non-null    float64
     8   LoanAmount         592 non-null    float64
     9   Loan_Amount_Term   600 non-null    float64
     10  Credit_History     564 non-null    float64
     11  Property_Area      614 non-null    object 
     12  Loan_Status        614 non-null    object 
    dtypes: float64(4), int64(1), object(8)
    memory usage: 62.5+ KB
    

#check for the detailed datatypes of the training dataset df2.info()

.. code:: ipython3

    #Rowss and columns details
    df1.shape, df2.shape




.. parsed-literal::

    ((614, 13), (367, 12))



EDA
---

Univariate Analysis
~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # count the values as per loan status
    df1["Loan_Status"].value_counts()




.. parsed-literal::

    Y    422
    N    192
    Name: Loan_Status, dtype: int64



.. code:: ipython3

    #proportion wise value counts
    df1["Loan_Status"].value_counts(normalize = True)




.. parsed-literal::

    Y    0.687296
    N    0.312704
    Name: Loan_Status, dtype: float64



.. code:: ipython3

    df1["Loan_Status"].value_counts(normalize = True).plot.bar()




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x199dd784700>




.. image:: output_12_1.png


.. code:: ipython3

    # Form a subset of categoricl variables
    Cat_col =df1[['Gender','Married','Education','Dependents','Property_Area','Self_Employed']]
    Con_col =df1[['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
                  'Loan_Amount_Term', 'Credit_History']]

.. code:: ipython3

    #Barplot plot for the CATEGORICAL variables
    
    fig = plt.figure(figsize=(10,8))
    for i in range(len(Cat_col.columns)):
        plt.subplot(2,4,i+1)
        sns.countplot(x=Cat_col.iloc[:,i], data=Cat_col.dropna())
    #    plt.xticks(rotation=90)
    fig.tight_layout(pad=1.0)



.. image:: output_14_0.png


.. code:: ipython3

    plt.figure(1) 
    plt.subplot(131)
    df1['Dependents'].value_counts(normalize = True).plot.bar(figsize = (24,6), title = 'Dependents')
    plt.subplot(132)
    df1['Education'].value_counts(normalize = True).plot.bar(title = 'Education')
    plt.subplot(133)
    df1['Property_Area'].value_counts(normalize = True).plot.bar(title = 'Property_Area')
    plt.show()
    



.. image:: output_15_0.png


.. code:: ipython3

    #Check with the distribution of each one of the attributes
    plt.figure(1) 
    Con_col.plot.box(figsize = (16,5))
    plt.show()



.. parsed-literal::

    <Figure size 432x288 with 0 Axes>



.. image:: output_16_1.png


.. code:: ipython3

    #histogram plot for the continuous variables
    plt.figure(1)
    Con_col.hist(figsize= (8,8))
    plt.show()



.. parsed-literal::

    <Figure size 432x288 with 0 Axes>



.. image:: output_17_1.png


Bivariate Analysis
~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    plt.figure(1) 
    plt.figure(figsize=(6,6))
    sns.countplot(x='Gender', data=df1, hue='Loan_Status')
    plt.figure(figsize=(6,6))
    sns.countplot(x='Married', data=df1, hue='Loan_Status')
    plt.figure(figsize=(6,6))
    sns.countplot(x='Education', data=df1, hue='Loan_Status')
    plt.figure(figsize=(6,6))
    sns.countplot(x='Dependents', data=df1, hue='Loan_Status')
    plt.figure(figsize=(6,6))
    sns.countplot(x='Property_Area', data=df1, hue='Loan_Status')
    plt.figure(figsize=(6,6))
    sns.countplot(x='Self_Employed', data=df1, hue='Loan_Status')
    plt.show()



.. parsed-literal::

    <Figure size 432x288 with 0 Axes>



.. image:: output_19_1.png



.. image:: output_19_2.png



.. image:: output_19_3.png



.. image:: output_19_4.png



.. image:: output_19_5.png



.. image:: output_19_6.png


.. code:: ipython3

    #Replace the Loan Status into numerical values
    df1.replace({"Loan_Status":{'N':0.0,'Y':1.0}},inplace=True)

Correlation Matrix
~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    corrmat = df1.corr() 
    fig = plt.figure(figsize = (12, 9)) 
    sns.heatmap(corrmat, annot = True, vmax = .8, square = True, cmap ='BuPu') 
    plt.show() 



.. image:: output_22_0.png


.. code:: ipython3

    corrmat = df2.corr() 
    fig = plt.figure(figsize = (12, 9)) 
    sns.heatmap(corrmat, annot = True, vmax = .8, square = True, cmap ='BuPu') 
    plt.show() 



.. image:: output_23_0.png


DATA CLEANING
-------------

Missing value treatment
~~~~~~~~~~~~~~~~~~~~~~~

Replace the categorical values with Mode and continuous values with
Median PS- As the Gender wise column is controversial to replace with
the mode values, hence we will let them be.

Train data
~~~~~~~~~~

.. code:: ipython3

    df1[df1.columns[df1.isnull().any()]].isnull().sum()
    # presence of missing values in the following




.. parsed-literal::

    Gender              13
    Married              3
    Dependents          15
    Self_Employed       32
    LoanAmount          22
    Loan_Amount_Term    14
    Credit_History      50
    dtype: int64



.. code:: ipython3

     # Importing the statistics module
    from statistics import mode 

.. code:: ipython3

    #Replacement for categorical values- trained data
    for i in ['Gender','Dependents', 'Married', 'Self_Employed']:
        df1[i].fillna(df1[i].mode()[0], inplace=True)

.. code:: ipython3

    #Replacement for continuous values- trained data
    for j in ['LoanAmount', 'Loan_Amount_Term','Credit_History']:
        df1[j].fillna(df1[j].median(), inplace=True)

.. code:: ipython3

    df1[df1.columns[df1.isnull().any()]].isnull().sum()




.. parsed-literal::

    Series([], dtype: float64)



.. code:: ipython3

    #data types for the trained data
    df1.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 614 entries, 0 to 613
    Data columns (total 13 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Loan_ID            614 non-null    object 
     1   Gender             614 non-null    object 
     2   Married            614 non-null    object 
     3   Dependents         614 non-null    object 
     4   Education          614 non-null    object 
     5   Self_Employed      614 non-null    object 
     6   ApplicantIncome    614 non-null    int64  
     7   CoapplicantIncome  614 non-null    float64
     8   LoanAmount         614 non-null    float64
     9   Loan_Amount_Term   614 non-null    float64
     10  Credit_History     614 non-null    float64
     11  Property_Area      614 non-null    object 
     12  Loan_Status        614 non-null    object 
    dtypes: float64(4), int64(1), object(8)
    memory usage: 62.5+ KB
    

Test data
~~~~~~~~~

.. code:: ipython3

    df2[df2.columns[df2.isnull().any()]].isnull().sum()
    # presence of missing values in the following




.. parsed-literal::

    Gender              11
    Dependents          10
    Self_Employed       23
    LoanAmount           5
    Loan_Amount_Term     6
    Credit_History      29
    dtype: int64



.. code:: ipython3

    #Replacement for categorical values- test data
    for i in ['Gender','Dependents','Self_Employed']:
        df2[i].fillna(df2[i].mode()[0], inplace=True)

.. code:: ipython3

    #Replacement for continuous values- test data
    for j in ['LoanAmount', 'Loan_Amount_Term','Credit_History']:
        df2[j].fillna(df2[j].median(), inplace=True)
        

.. code:: ipython3

    df2[df2.columns[df2.isnull().any()]].isnull().sum()




.. parsed-literal::

    Series([], dtype: float64)



.. code:: ipython3

    #data types for the test data
    df2.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 367 entries, 0 to 366
    Data columns (total 12 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Loan_ID            367 non-null    object 
     1   Gender             367 non-null    object 
     2   Married            367 non-null    object 
     3   Dependents         367 non-null    object 
     4   Education          367 non-null    object 
     5   Self_Employed      367 non-null    object 
     6   ApplicantIncome    367 non-null    int64  
     7   CoapplicantIncome  367 non-null    int64  
     8   LoanAmount         367 non-null    float64
     9   Loan_Amount_Term   367 non-null    float64
     10  Credit_History     367 non-null    float64
     11  Property_Area      367 non-null    object 
    dtypes: float64(3), int64(2), object(7)
    memory usage: 34.5+ KB
    

Duplicate Value treatment
~~~~~~~~~~~~~~~~~~~~~~~~~

Check for the no. of duplicate values and treat them as required

.. code:: ipython3

    print("total number of duplicates =",len(df1[df1.duplicated()]))


.. parsed-literal::

    total number of duplicates = 0
    

.. code:: ipython3

    print("total number of duplicates =",len(df2[df2.duplicated()]))


.. parsed-literal::

    total number of duplicates = 0
    

Outliers treatment
~~~~~~~~~~~~~~~~~~

Check for the Outliers among all the attributes

.. code:: ipython3

    outliers =[]
    def detect_outliers(df1):
        threshold = 3
        mean = np.mean(df1)
        std = np.std(df1)
        
        for y in df1:
            z_score = (y-mean)/std
            if np.abs(z_score)>threshold:
                outliers.append(y)
        return outliers 

.. code:: ipython3

    #detection of outliers in the amount column
    outliers_datapoints = detect_outliers(df1['ApplicantIncome']) 
    print(outliers_datapoints)
    #very few nos of datapoints are in the Outlier Zone


.. parsed-literal::

    [23803, 39999, 51763, 33846, 39147, 63337, 81000, 37719]
    


Feature Engineering
~~~~~~~~~~~~~~~~~~~

Form a new column ‘Total Income’ which is the combination of
ApplicantIncome and CoapplicantIncome

Drop the unnecessary columns from the dataset

.. code:: ipython3

    df1['TotalIncome']= df1['ApplicantIncome'] + df1['CoapplicantIncome']

.. code:: ipython3

    df2['TotalIncome']= df2['ApplicantIncome'] + df2['CoapplicantIncome']

Log Transformation
~~~~~~~~~~~~~~~~~~

It is being done in order to reduce skewness

Applied to Applicant income, Coapplicant Income, Loan Amount, Loan
Amount Term, Credit History

.. code:: ipython3

    #df1[['ApplicantIncome_log','CoapplicantIncome_log', 'LoanAmount_log','Loan_Amount_Term_log']]= np.log(df1[['ApplicantIncome','CoapplicantIncome', 'LoanAmount','Loan_Amount_Term']])

.. code:: ipython3

    #df2[['ApplicantIncome_log','CoapplicantIncome_log', 'LoanAmount_log','Loan_Amount_Term_log']]= np.log(df2[['ApplicantIncome','CoapplicantIncome', 'LoanAmount','Loan_Amount_Term']])

.. code:: ipython3

    df1[['TotalIncome_log', 'LoanAmount_log','Loan_Amount_Term_log']]= np.log(df1[['TotalIncome', 'LoanAmount','Loan_Amount_Term']])

.. code:: ipython3

    df2[['TotalIncome_log', 'LoanAmount_log','Loan_Amount_Term_log']]= np.log(df2[['TotalIncome', 'LoanAmount','Loan_Amount_Term']])

.. code:: ipython3

    df1.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Loan_ID</th>
          <th>Gender</th>
          <th>Married</th>
          <th>Dependents</th>
          <th>Education</th>
          <th>Self_Employed</th>
          <th>ApplicantIncome</th>
          <th>CoapplicantIncome</th>
          <th>LoanAmount</th>
          <th>Loan_Amount_Term</th>
          <th>Credit_History</th>
          <th>Property_Area</th>
          <th>Loan_Status</th>
          <th>TotalIncome</th>
          <th>TotalIncome_log</th>
          <th>LoanAmount_log</th>
          <th>Loan_Amount_Term_log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>LP001002</td>
          <td>Male</td>
          <td>No</td>
          <td>0</td>
          <td>Graduate</td>
          <td>No</td>
          <td>5849</td>
          <td>0.0</td>
          <td>128.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>5849.0</td>
          <td>8.674026</td>
          <td>4.852030</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>1</th>
          <td>LP001003</td>
          <td>Male</td>
          <td>Yes</td>
          <td>1</td>
          <td>Graduate</td>
          <td>No</td>
          <td>4583</td>
          <td>1508.0</td>
          <td>128.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Rural</td>
          <td>0.0</td>
          <td>6091.0</td>
          <td>8.714568</td>
          <td>4.852030</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>2</th>
          <td>LP001005</td>
          <td>Male</td>
          <td>Yes</td>
          <td>0</td>
          <td>Graduate</td>
          <td>Yes</td>
          <td>3000</td>
          <td>0.0</td>
          <td>66.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>3000.0</td>
          <td>8.006368</td>
          <td>4.189655</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>3</th>
          <td>LP001006</td>
          <td>Male</td>
          <td>Yes</td>
          <td>0</td>
          <td>Not Graduate</td>
          <td>No</td>
          <td>2583</td>
          <td>2358.0</td>
          <td>120.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>4941.0</td>
          <td>8.505323</td>
          <td>4.787492</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>4</th>
          <td>LP001008</td>
          <td>Male</td>
          <td>No</td>
          <td>0</td>
          <td>Graduate</td>
          <td>No</td>
          <td>6000</td>
          <td>0.0</td>
          <td>141.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>6000.0</td>
          <td>8.699515</td>
          <td>4.948760</td>
          <td>5.886104</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df2.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Loan_ID</th>
          <th>Gender</th>
          <th>Married</th>
          <th>Dependents</th>
          <th>Education</th>
          <th>Self_Employed</th>
          <th>ApplicantIncome</th>
          <th>CoapplicantIncome</th>
          <th>LoanAmount</th>
          <th>Loan_Amount_Term</th>
          <th>Credit_History</th>
          <th>Property_Area</th>
          <th>TotalIncome</th>
          <th>TotalIncome_log</th>
          <th>LoanAmount_log</th>
          <th>Loan_Amount_Term_log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>LP001015</td>
          <td>Male</td>
          <td>Yes</td>
          <td>0</td>
          <td>Graduate</td>
          <td>No</td>
          <td>5720</td>
          <td>0</td>
          <td>110.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>5720</td>
          <td>8.651724</td>
          <td>4.700480</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>1</th>
          <td>LP001022</td>
          <td>Male</td>
          <td>Yes</td>
          <td>1</td>
          <td>Graduate</td>
          <td>No</td>
          <td>3076</td>
          <td>1500</td>
          <td>126.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>4576</td>
          <td>8.428581</td>
          <td>4.836282</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>2</th>
          <td>LP001031</td>
          <td>Male</td>
          <td>Yes</td>
          <td>2</td>
          <td>Graduate</td>
          <td>No</td>
          <td>5000</td>
          <td>1800</td>
          <td>208.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>6800</td>
          <td>8.824678</td>
          <td>5.337538</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>3</th>
          <td>LP001035</td>
          <td>Male</td>
          <td>Yes</td>
          <td>2</td>
          <td>Graduate</td>
          <td>No</td>
          <td>2340</td>
          <td>2546</td>
          <td>100.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>4886</td>
          <td>8.494129</td>
          <td>4.605170</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>4</th>
          <td>LP001051</td>
          <td>Male</td>
          <td>No</td>
          <td>0</td>
          <td>Not Graduate</td>
          <td>No</td>
          <td>3276</td>
          <td>0</td>
          <td>78.0</td>
          <td>360.0</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>3276</td>
          <td>8.094378</td>
          <td>4.356709</td>
          <td>5.886104</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #drop unnecessary columns for trained data
    col = ['ApplicantIncome','CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term','TotalIncome']
    df1 = df1.drop(columns=col, axis=1)
    df1.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Loan_ID</th>
          <th>Gender</th>
          <th>Married</th>
          <th>Dependents</th>
          <th>Education</th>
          <th>Self_Employed</th>
          <th>Credit_History</th>
          <th>Property_Area</th>
          <th>Loan_Status</th>
          <th>TotalIncome_log</th>
          <th>LoanAmount_log</th>
          <th>Loan_Amount_Term_log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>LP001002</td>
          <td>Male</td>
          <td>No</td>
          <td>0</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>8.674026</td>
          <td>4.852030</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>1</th>
          <td>LP001003</td>
          <td>Male</td>
          <td>Yes</td>
          <td>1</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Rural</td>
          <td>0.0</td>
          <td>8.714568</td>
          <td>4.852030</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>2</th>
          <td>LP001005</td>
          <td>Male</td>
          <td>Yes</td>
          <td>0</td>
          <td>Graduate</td>
          <td>Yes</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>8.006368</td>
          <td>4.189655</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>3</th>
          <td>LP001006</td>
          <td>Male</td>
          <td>Yes</td>
          <td>0</td>
          <td>Not Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>8.505323</td>
          <td>4.787492</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>4</th>
          <td>LP001008</td>
          <td>Male</td>
          <td>No</td>
          <td>0</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>1.0</td>
          <td>8.699515</td>
          <td>4.948760</td>
          <td>5.886104</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #drop unnecessary columns for test data
    col = ['ApplicantIncome','CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term','TotalIncome']
    df2 = df2.drop(columns=col, axis=1)
    df2.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Loan_ID</th>
          <th>Gender</th>
          <th>Married</th>
          <th>Dependents</th>
          <th>Education</th>
          <th>Self_Employed</th>
          <th>Credit_History</th>
          <th>Property_Area</th>
          <th>TotalIncome_log</th>
          <th>LoanAmount_log</th>
          <th>Loan_Amount_Term_log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>LP001015</td>
          <td>Male</td>
          <td>Yes</td>
          <td>0</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>8.651724</td>
          <td>4.700480</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>1</th>
          <td>LP001022</td>
          <td>Male</td>
          <td>Yes</td>
          <td>1</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>8.428581</td>
          <td>4.836282</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>2</th>
          <td>LP001031</td>
          <td>Male</td>
          <td>Yes</td>
          <td>2</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>8.824678</td>
          <td>5.337538</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>3</th>
          <td>LP001035</td>
          <td>Male</td>
          <td>Yes</td>
          <td>2</td>
          <td>Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>8.494129</td>
          <td>4.605170</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>4</th>
          <td>LP001051</td>
          <td>Male</td>
          <td>No</td>
          <td>0</td>
          <td>Not Graduate</td>
          <td>No</td>
          <td>1.0</td>
          <td>Urban</td>
          <td>8.094378</td>
          <td>4.356709</td>
          <td>5.886104</td>
        </tr>
      </tbody>
    </table>
    </div>



Label encoding-
~~~~~~~~~~~~~~~

Label Encoding refers to converting the labels into numeric form so as
to convert it into the machine-readable form

.. code:: ipython3

    from sklearn.preprocessing import LabelEncoder
    cols = ['Gender',"Married","Education",'Self_Employed',"Property_Area","Dependents"]
    le = LabelEncoder()
    for col in cols:
        df1[col] = le.fit_transform(df1[col])

.. code:: ipython3

    from sklearn.preprocessing import LabelEncoder
    cols = ['Gender',"Married","Education",'Self_Employed',"Property_Area","Dependents"]
    le = LabelEncoder()
    for col in cols:
        df2[col] = le.fit_transform(df2[col])

.. code:: ipython3

    #Droping the load id from both the datasets and naming them as train n test
    train = df1.drop('Loan_ID', axis = 1)
    test = df2.drop('Loan_ID', axis = 1)

.. code:: ipython3

    #check to replace inf with 1
    from numpy import inf
    train[train == -inf] = 1

.. code:: ipython3

    #check to replace inf with 1
    test[test == -inf] = 1
    

.. code:: ipython3

    train.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Gender</th>
          <th>Married</th>
          <th>Dependents</th>
          <th>Education</th>
          <th>Self_Employed</th>
          <th>Credit_History</th>
          <th>Property_Area</th>
          <th>Loan_Status</th>
          <th>TotalIncome_log</th>
          <th>LoanAmount_log</th>
          <th>Loan_Amount_Term_log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>1.0</td>
          <td>8.674026</td>
          <td>4.852030</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>0</td>
          <td>0.0</td>
          <td>8.714568</td>
          <td>4.852030</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1.0</td>
          <td>2</td>
          <td>1.0</td>
          <td>8.006368</td>
          <td>4.189655</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>1.0</td>
          <td>8.505323</td>
          <td>4.787492</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>1.0</td>
          <td>8.699515</td>
          <td>4.948760</td>
          <td>5.886104</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    test.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Gender</th>
          <th>Married</th>
          <th>Dependents</th>
          <th>Education</th>
          <th>Self_Employed</th>
          <th>Credit_History</th>
          <th>Property_Area</th>
          <th>TotalIncome_log</th>
          <th>LoanAmount_log</th>
          <th>Loan_Amount_Term_log</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>8.651724</td>
          <td>4.700480</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>8.428581</td>
          <td>4.836282</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1</td>
          <td>1</td>
          <td>2</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>8.824678</td>
          <td>5.337538</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>1</td>
          <td>2</td>
          <td>0</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>8.494129</td>
          <td>4.605170</td>
          <td>5.886104</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1.0</td>
          <td>2</td>
          <td>8.094378</td>
          <td>4.356709</td>
          <td>5.886104</td>
        </tr>
      </tbody>
    </table>
    </div>




Model Training
--------------

.. code:: ipython3

    # specify input and output attributes using feature and targets
    x = train.drop('Loan_Status', 1)
    y = train.Loan_Status

.. code:: ipython3

    # Build dummies for label encoding
    x = pd.get_dummies(x)
    train = pd.get_dummies(train)
    test = pd.get_dummies(test)

.. code:: ipython3

    #Splitting the data into training and test dataset
    from sklearn.model_selection import train_test_split

.. code:: ipython3

    #import the classes associated with the modules required for training the dataset
    import sklearn.metrics
    from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, auc, roc_curve 
    from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
    from sklearn.model_selection import cross_val_score  #For K-fold cross validation

Check for Class imbalance
~~~~~~~~~~~~~~~~~~~~~~~~~

As we can witness, that there has been quite an imbalance in the
transaction data based on Class ie,

Loan_Provided : 422

Loan_Rejected : 192

Hence, in order to reduce such class imbalance, we must opt for two
processes 1. Random Over Sampling 2. Random Under Sampling

.. code:: ipython3

    #to deal with sampling techniques, we need to install the following package
    !pip install imblearn


.. parsed-literal::

    Requirement already satisfied: imblearn in d:\applications\study_apps\anaconda\lib\site-packages (0.0)
    Requirement already satisfied: imbalanced-learn in d:\applications\study_apps\anaconda\lib\site-packages (from imblearn) (0.7.0)
    Requirement already satisfied: scipy>=0.19.1 in d:\applications\study_apps\anaconda\lib\site-packages (from imbalanced-learn->imblearn) (1.5.0)
    Requirement already satisfied: joblib>=0.11 in d:\applications\study_apps\anaconda\lib\site-packages (from imbalanced-learn->imblearn) (0.16.0)
    Requirement already satisfied: scikit-learn>=0.23 in d:\applications\study_apps\anaconda\lib\site-packages (from imbalanced-learn->imblearn) (0.23.1)
    Requirement already satisfied: numpy>=1.13.3 in d:\applications\study_apps\anaconda\lib\site-packages (from imbalanced-learn->imblearn) (1.18.5)
    Requirement already satisfied: threadpoolctl>=2.0.0 in d:\applications\study_apps\anaconda\lib\site-packages (from scikit-learn>=0.23->imbalanced-learn->imblearn) (2.1.0)
    

.. code:: ipython3

    #Install the modules associated with this package
    from imblearn.over_sampling import RandomOverSampler,SMOTE, ADASYN
    from imblearn.under_sampling import RandomUnderSampler

.. code:: ipython3

    from collections import Counter # counter takes values returns value_counts dictionary
    from sklearn.datasets import make_classification # to generate a random n class classification problem
    
    #x, y = make_classification(n_classes=2) #, class_sep=2,weights=[0.1, 0.9], n_informative=3, n_redundant=1, flip_y=0,n_features=20, n_clusters_per_class=1, n_samples=1000, random_state=10)
    print('Original dataset shape %s' % Counter(y))


.. parsed-literal::

    Original dataset shape Counter({1.0: 422, 0.0: 192})
    

Random Under Sampling
^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    #Use of random under sampling method 
    rus = RandomUnderSampler(random_state=42)
    
    x_rus, y_rus = rus.fit_resample(x, y)
    print('Resampled dataset shape %s' % Counter(y_rus))


.. parsed-literal::

    Resampled dataset shape Counter({0.0: 192, 1.0: 192})
    

Random Over Sampling
^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    #Use of random over sampling method 
    ros = RandomOverSampler(random_state= 42)
    
    x_ros, y_ros = ros.fit_resample(x, y)
    print('Resampled dataset shape %s' % Counter(y_ros))


.. parsed-literal::

    Resampled dataset shape Counter({1.0: 422, 0.0: 422})
    

SMOTE
^^^^^

.. code:: ipython3

    #Use of random over sampling method 
    ros1 = SMOTE(random_state= 42)
    
    x_ros1, y_ros1 = ros1.fit_resample(x, y)
    print('Resampled dataset shape %s' % Counter(y_ros1))


.. parsed-literal::

    Resampled dataset shape Counter({1.0: 422, 0.0: 422})
    

.. code:: ipython3

    #import the Random Forest module
    !pip3 install xgboost
    from xgboost import XGBClassifier 


.. parsed-literal::

    Requirement already satisfied: xgboost in d:\applications\study_apps\anaconda\lib\site-packages (1.3.0.post0)
    Requirement already satisfied: scipy in d:\applications\study_apps\anaconda\lib\site-packages (from xgboost) (1.5.0)
    Requirement already satisfied: numpy in d:\applications\study_apps\anaconda\lib\site-packages (from xgboost) (1.18.5)
    

.. code:: ipython3

    #. Logistic Regression - using Random under Sampling
    #split the data into train and validation sets
    x_train,x_val,y_train,y_val = train_test_split(x_ros,y_ros, test_size = 0.3, random_state = 0)
    
    #train the model
    xgbc =XGBClassifier(n_estimators=100)
    
    xgbc.fit(x_train, y_train)
    
    #predict the model
    y_pred = xgbc.predict(x_val)
    
    #check for the accuracy score
    print(f"Accuracy_Score_of_XGBoost(ROS): {accuracy_score(y_pred, y_val)}")
    score = cross_val_score(xgbc, x_ros, y_ros, cv=5)
    print("Cross validation is",np.mean(score)*100)
    
    


.. parsed-literal::

    [14:39:33] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.3.0/src/learner.cc:1061: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.
    Accuracy_Score_of_XGBoost(ROS): 0.8661417322834646
    [14:39:33] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.3.0/src/learner.cc:1061: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.
    [14:39:33] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.3.0/src/learner.cc:1061: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.
    [14:39:33] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.3.0/src/learner.cc:1061: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.
    [14:39:33] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.3.0/src/learner.cc:1061: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.
    [14:39:34] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.3.0/src/learner.cc:1061: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.
    Cross validation is 86.96745562130177
    

.. code:: ipython3

    #Predict the same for the test dataset
    y_pred_test = xgbc.predict(test)

Check with the submission dataset
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    submission = pd.read_csv("sample_submission_49d68Cx (1).csv")

.. code:: ipython3

    submission['Loan_Status'] = y_pred_test

.. code:: ipython3

    submission['Loan_ID'] = test_original['Loan_ID']

.. code:: ipython3

    #convert predictions from Y/N to 1/0
    #submission.replace({"Loan_Status":{'N':0,'Y':1}},inplace=True)

.. code:: ipython3

    submission.replace({"Loan_Status":{0 : 'N',1 :'Y'}},inplace=True)

.. code:: ipython3

    pd.DataFrame(submission, columns = ['Loan_ID','Loan_Status']).to_csv('Xgboost_ROS-log_2.csv', index = False)
